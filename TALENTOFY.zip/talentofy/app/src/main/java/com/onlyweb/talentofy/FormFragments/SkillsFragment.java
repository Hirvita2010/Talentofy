package com.onlyweb.talentofy.FormFragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.onlyweb.talentofy.R;
import com.onlyweb.talentofy.RVFragSkillAdapter;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class SkillsFragment extends Fragment {
    private ArrayList<Skill> skills;
    private RVFragSkillAdapter adapter;
    private SharedPreferences sharedPreferences;
    private Button nextButton;
    private static final String SKILLS_PREFS = "MyPrefs";
    private static final String SKILLS_KEY = "skills";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_skills, container, false);

        sharedPreferences = requireActivity().getSharedPreferences(SKILLS_PREFS, Context.MODE_PRIVATE);
        skills = loadSkillsFromPrefs();

        RecyclerView recyclerView = view.findViewById(R.id.container_skill_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new RVFragSkillAdapter(getContext(), skills);
        recyclerView.setAdapter(adapter);

        nextButton = view.findViewById(R.id.btn_next);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to LanguageFragment
                LanguageFragment languageFragment = new LanguageFragment();
                requireActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, languageFragment)
                        .addToBackStack(null)
                        .commit();
            }
        });

        Button addButton = view.findViewById(R.id.form_skill_btn_add);
        addButton.setOnClickListener(v -> showSkillsFormDialog());

        return view;
    }

    private void showSkillsFormDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.form_frag_skill, null);

        final TextInputEditText skillEt = view.findViewById(R.id.form_skill_et_skill);

        builder.setView(view)
                .setTitle("Add Skill")
                .setNeutralButton("Cancel", null)
                .setPositiveButton("Add", (dialogInterface, i) -> {
                    String skill = skillEt.getText().toString();
                    if (!skill.isEmpty()) {
                        skills.add(new Skill(skill));
                        saveSkillsToPrefs();
                        updateAdapter();
                        Toast.makeText(getContext(), "Skill added", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Skill cannot be empty", Toast.LENGTH_SHORT).show();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void saveSkillsToPrefs() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(skills);
        editor.putString(SKILLS_KEY, json);
        editor.apply();
    }

    private ArrayList<Skill> loadSkillsFromPrefs() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString(SKILLS_KEY, null);
        Type type = new TypeToken<ArrayList<Skill>>() {}.getType();
        ArrayList<Skill> loadedskills = gson.fromJson(json, type);
        return loadedskills == null ? new ArrayList<>() : loadedskills;
    }

    private void updateAdapter() {
        adapter.notifyDataSetChanged();
    }

    // Define the Skill class within the fragment or as a separate class
    public static class Skill {
        private String skill;

        public Skill(String skill) {
            this.skill = skill;
        }

        public String getSkillName() {
            return skill;
        }
    }
}
