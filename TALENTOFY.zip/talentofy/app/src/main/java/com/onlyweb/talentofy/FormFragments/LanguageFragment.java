package com.onlyweb.talentofy.FormFragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.onlyweb.talentofy.RVFragLanguageAdapter;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.onlyweb.talentofy.R;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class LanguageFragment extends Fragment {
    private ArrayList<Language> languages;
    private RVFragLanguageAdapter adapter;
    private SharedPreferences sharedPreferences;
    private Button nextButton;
    private static final String LANG_PREFS = "MyPrefs";
    private static final String LANG_KEY = "lang_key";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_language, container, false);

        sharedPreferences = requireActivity().getSharedPreferences(LANG_PREFS, Context.MODE_PRIVATE);
        languages = loadLanguageFromPrefs();

        RecyclerView recyclerView = view.findViewById(R.id.container_lang_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new RVFragLanguageAdapter(getContext(), languages);
        recyclerView.setAdapter(adapter);

        nextButton = view.findViewById(R.id.btn_next);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to ObjectiveFragment
                ObjectiveFragment objectiveFragment = new ObjectiveFragment();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.container, objectiveFragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        Button addButton = view.findViewById(R.id.form_lang_btn_add);
        addButton.setOnClickListener(v -> showLanguageFormDialog());

        return view;
    }

    private void showLanguageFormDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.form_frag_lang, null);

        final TextInputEditText langEt = view.findViewById(R.id.form_lang_et_lang);

        builder.setView(view)
                .setTitle("Add Languages")
                .setNeutralButton("Cancel", null)
                .setPositiveButton("Add", (dialogInterface, i) -> {
                    String lang = langEt.getText().toString();
                    if (!lang.isEmpty()) {
                        languages.add(new Language(lang));
                        saveLanguageToPrefs();
                        updateAdapter();
                        Toast.makeText(getContext(), "Language added", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Language cannot be empty", Toast.LENGTH_SHORT).show();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void saveLanguageToPrefs() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(languages);
        editor.putString(LANG_KEY, json);
        editor.apply();
    }

    private ArrayList<Language> loadLanguageFromPrefs() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString(LANG_KEY, null);
        Type type = new TypeToken<ArrayList<Language>>() {}.getType();
        ArrayList<Language> loadedLanguages = gson.fromJson(json, type);
        return loadedLanguages == null ? new ArrayList<>() : loadedLanguages;
    }

    private void updateAdapter() {
        adapter.notifyDataSetChanged();
    }

    // Convert the list of skills to a comma-separated string


    // Define the Skill class within the fragment or as a separate class
    public static class Language {
        private String language;

        public Language(String language) {
            this.language = language;
        }

        public String getLanguage() {
            return language;
        }
    }
}
