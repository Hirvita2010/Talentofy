package com.onlyweb.talentofy;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.MobileAds;
import com.onlyweb.talentofy.FormFragments.EducationFragment;
import com.onlyweb.talentofy.FormFragments.ExperienceFragment;
import com.onlyweb.talentofy.FormFragments.LanguageFragment;
import com.onlyweb.talentofy.FormFragments.ProjectsFragment;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Scanner;

public class ViewCVActivity extends AppCompatActivity {

    private static final String TAG = "ViewCVActivity";
    private WebView webView;
    private String name;
    private String profileImageUriString;
    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_cv);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        webView = findViewById(R.id.webView);
        if (webView == null) {
            throw new IllegalStateException("WebView with ID 'webView' not found in layout file");
        }
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setLoadWithOverviewMode(true); // Initially fit content to screen
        webView.getSettings().setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }
        });

        // Initialize Mobile Ads SDK
        MobileAds.initialize(this, initializationStatus -> {
            loadInterstitialAd();
        });

        String htmlFileName = getIntent().getStringExtra("HTML_FILE_NAME");
        if (htmlFileName != null) {
            loadHTMLContent(htmlFileName);
        } else {
            Toast.makeText(this, "No template selected", Toast.LENGTH_SHORT).show();
        }

        Button pdfButton = findViewById(R.id.pdfButton);
        pdfButton.setOnClickListener(v -> {
            showInterstitialAd(() -> pdfButton()); // Handle PDF generation
        });

        Button saveButton = findViewById(R.id.saveButton); // Assuming you have a button with id saveButton
        saveButton.setOnClickListener(v -> showInterstitialAd(() -> saveResumeToFile("resume.json", name, profileImageUriString)));
    }

    private void loadInterstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, "ca-app-pub-9405167098279820/2295370436", adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        Log.i(TAG, "onAdLoaded");
                        mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                Log.d(TAG, "The ad was dismissed.");
                                loadInterstitialAd();
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                                Log.d(TAG, "The ad failed to show.");
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                Log.d(TAG, "The ad was shown.");
                                mInterstitialAd = null;
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError loadAdError) {
                        Log.i(TAG, loadAdError.getMessage());
                        mInterstitialAd = null;
                    }
                });
    }

    private void showInterstitialAd(Runnable onAdDismissed) {
        if (mInterstitialAd != null) {
            mInterstitialAd.show(this);
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    onAdDismissed.run();
                    loadInterstitialAd();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                    onAdDismissed.run();
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    mInterstitialAd = null;
                }
            });
        } else {
            onAdDismissed.run();
            loadInterstitialAd();
        }
    }



    private void loadHTMLContent(String htmlFileName) {
        // Retrieve personal details
        SharedPreferences personalSharedPreferences = getSharedPreferences("PersonalData", Context.MODE_PRIVATE);
        String name = personalSharedPreferences.getString("name", "");
        String email = personalSharedPreferences.getString("email", "");
        String phone = personalSharedPreferences.getString("phone", "");
        String address = personalSharedPreferences.getString("address", "");
        String linkedin = personalSharedPreferences.getString("linkedin", "");
        String profession = personalSharedPreferences.getString("profession", "");
        String profileImageUriString = personalSharedPreferences.getString("profileImageUri", "");

        // Retrieve objective
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String objective = sharedPreferences.getString("objective", "");

        // Retrieve skills
        String skillsJson = sharedPreferences.getString("skills", "");
        ArrayList<String> skillsList = new ArrayList<>();
        if (skillsJson != null) {
            try {
                JSONArray skillsArray = new JSONArray(skillsJson);
                for (int i = 0; i < skillsArray.length(); i++) {
                    JSONObject skillObject = skillsArray.getJSONObject(i);
                    String skill = skillObject.getString("skill");
                    skillsList.add(skill);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        // Retrieve languages
        String languagesJson = sharedPreferences.getString("lang_key", "");

        // Retrieve projects
        SharedPreferences projectSharedPreferences = getSharedPreferences("ProjectData", Context.MODE_PRIVATE);
        String projectsJson = projectSharedPreferences.getString("projectList", "");

        // Retrieve experience
        SharedPreferences experienceSharedPreferences = getSharedPreferences("ExperienceData", Context.MODE_PRIVATE);
        String experienceJson = experienceSharedPreferences.getString("experienceList", "");

        // Retrieve education
        SharedPreferences educationSharedPreferences = getSharedPreferences("EducationData", Context.MODE_PRIVATE);
        String educationJson = educationSharedPreferences.getString("educationList", "");

        // Load HTML content
        try {
            InputStream inputStream = getAssets().open(htmlFileName);
            Scanner scanner = new Scanner(inputStream).useDelimiter("\\A");
            String htmlContent = scanner.hasNext() ? scanner.next() : "";
            scanner.close();

            // Replace placeholders
            if (name != null) {
                htmlContent = htmlContent.replace("{NAME}", name);
            } else {
                htmlContent = htmlContent.replace("{NAME}", "");
            }

            if (email != null) {
                htmlContent = htmlContent.replace("{EMAIL}", email);
            } else {
                htmlContent = htmlContent.replace("{EMAIL}", "");
            }

            if (phone != null) {
                htmlContent = htmlContent.replace("{PHONE}", phone);
            } else {
                htmlContent = htmlContent.replace("{PHONE}", "");
            }

            if (address != null) {
                htmlContent = htmlContent.replace("{ADDRESS}", address);
            } else {
                htmlContent = htmlContent.replace("{ADDRESS}", "");
            }

            if (linkedin != null) {
                htmlContent = htmlContent.replace("{LINKDIN}", linkedin);
            } else {
                htmlContent = htmlContent.replace("{LINKDIN}", "");
            }

            if (profileImageUriString != null) {
                htmlContent = htmlContent.replace("{PROFILE_PHOTO}", "<img src=\"" + profileImageUriString + "\" alt=\"Profile Photo\">");
            } else {
                htmlContent = htmlContent.replace("{PROFILE_PHOTO}", "");
            }

            if (profession != null) {
                htmlContent = htmlContent.replace("{PROFESSION}", profession);
            } else {
                htmlContent = htmlContent.replace("{PROFESSION}", "");
            }

            if (objective != null) {
                objective = formatParagraph(objective);
                htmlContent = htmlContent.replace("{OBJECTIVE}", objective);
            } else {
                htmlContent = htmlContent.replace("{OBJECTIVE}", "");
            }


            // Skills
            if (!skillsList.isEmpty()) {
                StringBuilder skillsStringBuilder = new StringBuilder();
                for (String skill : skillsList) {
                    skillsStringBuilder.append(skill).append("<br>");
                }
                htmlContent = htmlContent.replace("{SKILLS}", skillsStringBuilder.toString());
            } else {
                htmlContent = htmlContent.replace("{SKILLS}", "");
                htmlContent = htmlContent.replace("<div class=\"section\" id=\"skillsSection\">", "")
                        .replace("<div class=\"section__title\">Skills</div>", "")
                        .replace("<div class=\"skills\"><div class=\"skills__item\"><div class=\"left\"><div class=\"text\">{SKILLS}</div></div></div></div></div>", "");
            }

            // Languages
            if (languagesJson != null && !languagesJson.isEmpty()) {
                Gson gson = new Gson();
                Type languageListType = new TypeToken<ArrayList<LanguageFragment.Language>>() {}.getType();
                ArrayList<LanguageFragment.Language> languages = gson.fromJson(languagesJson, languageListType);
                StringBuilder languagesStringBuilder = new StringBuilder();
                if (languages != null && !languages.isEmpty()) {
                    for (LanguageFragment.Language language : languages) {
                        languagesStringBuilder.append(language.getLanguage()).append("<br>");
                    }
                    htmlContent = htmlContent.replace("{LANGUAGE}", languagesStringBuilder.toString());
                } else {
                    htmlContent = htmlContent.replace("{LANGUAGE}", "");
                    htmlContent = htmlContent.replace("<div class=\"section\" id=\"languagesSection\">", "")
                            .replace("<div class=\"section__title\">Languages</div>", "")
                            .replace("<div class=\"section_list\"><div class=\"section_list-item\">{LANGUAGE}</div></div></div>", "");
                }
            } else {
                htmlContent = htmlContent.replace("{LANGUAGE}", "");
                htmlContent = htmlContent.replace("<div class=\"section\" id=\"languagesSection\">", "")
                        .replace("<div class=\"section__title\">Languages</div>", "")
                        .replace("<div class=\"section_list\"><div class=\"section_list-item\">{LANGUAGE}</div></div></div>", "");
            }

            // Projects
            if (projectsJson != null) {
                Gson gson = new Gson();
                Type projectListType = new TypeToken<ArrayList<ProjectsFragment.Projects>>() {}.getType();
                ArrayList<ProjectsFragment.Projects> projects = gson.fromJson(projectsJson, projectListType);

                StringBuilder projectContentBuilder = new StringBuilder();

                if (projects != null) {
                    for (ProjectsFragment.Projects project : projects) {
                        // Append title and description together in sequence
                        projectContentBuilder.append("<strong>").append(project.getTitle()).append("</strong><br>")
                                .append(formatParagraph(project.getDesc())).append("<br><br>");
                    }
                }

                // Replace placeholder with combined project content
                htmlContent = htmlContent.replace("{PROJECTS}", projectContentBuilder.toString());
            } else {
                htmlContent = htmlContent.replace("{PROJECTS}", "");
            }

            // Education
            if (educationJson != null) {
                Gson gson = new Gson();
                Type educationListType = new TypeToken<ArrayList<EducationFragment.Education>>() {}.getType();
                ArrayList<EducationFragment.Education> educationList = gson.fromJson(educationJson, educationListType);

                StringBuilder educationContentBuilder = new StringBuilder();
                if (educationList != null) {
                    for (EducationFragment.Education edu : educationList) {
                        // Append degree, university, grade, and year in sequence
                        educationContentBuilder.append("<strong>").append(edu.getDegree()).append("</strong><br>")
                                .append(edu.getUniversity()).append("<br>")
                                .append(edu.getGrade()).append("<br>")
                                .append(edu.getYear()).append("<br><br>");
                    }
                }
                // Replace placeholder with combined education content
                htmlContent = htmlContent.replace("{EDUCATION}", educationContentBuilder.toString());
            } else {
                htmlContent = htmlContent.replace("{EDUCATION}", "");
            }

            // Experience
            if (experienceJson != null) {
                Gson gson = new Gson();
                Type experienceListType = new TypeToken<ArrayList<ExperienceFragment.Experience>>() {}.getType();
                ArrayList<ExperienceFragment.Experience> experienceList = gson.fromJson(experienceJson, experienceListType);
                StringBuilder experienceContentBuilder = new StringBuilder();

                if (experienceList != null) {
                    for (ExperienceFragment.Experience experience : experienceList) {
                        // Append company name, dates, job, and description in sequence
                        experienceContentBuilder.append("<strong>").append(experience.getCompany()).append("</strong><br>")
                                .append(experience.getSdate()).append(" - ").append(experience.getEdate()).append("<br>")
                                .append(experience.getJob()).append("<br>")
                                .append(formatDescription(experience.getDesc())).append("<br><br>");
                    }
                }
                // Replace placeholder with combined experience content
                htmlContent = htmlContent.replace("{EXPERIENCE}", experienceContentBuilder.toString());
            } else {
                htmlContent = htmlContent.replace("{EXPERIENCE}", "");
            }

            // Remove empty sections and their titles
            htmlContent = htmlContent.replaceAll("<div class=\"section\" id=\"[^\"]+\">\\s*<div class=\"section__title\">[^\"]+</div>\\s*<div class=\"[^\"]+\">\\s*</div>\\s*</div>", "");

            // Load HTML content into WebView
            webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private String replacePlaceholder(String htmlContent, String placeholder, String value) {
        return htmlContent.replace(placeholder, value != null ? value : "");
    }

    private String removeSection(String htmlContent, String sectionId, String placeholder) {
        return htmlContent.replace("<div class=\"section\" id=\"" + sectionId + "\">", "")
                .replace("<div class=\"section__title\">" + sectionId + "</div>", "")
                .replace(placeholder, "");
    }




    private String formatParagraph(String paragraph) {
        int maxCharactersPerLine = 50;
        StringBuilder formattedParagraph = new StringBuilder();
        int length = paragraph.length();
        for (int i = 0; i < length; i += maxCharactersPerLine) {
            String line = paragraph.substring(i, Math.min(length, i + maxCharactersPerLine));
            formattedParagraph.append(line);
            if (i + maxCharactersPerLine < length) {
                formattedParagraph.append("<br>");
            }
        }
        return formattedParagraph.toString();
    }

    private String formatDescription(String description) {
        int maxCharactersPerLine = 50;
        StringBuilder formattedDescription = new StringBuilder();
        String[] lines = description.split("\\r?\\n");
        for (String line : lines) {
            int length = line.length();
            for (int i = 0; i < length; i += maxCharactersPerLine) {
                String subLine = line.substring(i, Math.min(length, i + maxCharactersPerLine));
                formattedDescription.append(subLine);
                if (i + maxCharactersPerLine < length) {
                    formattedDescription.append("<br>");
                }
            }
            formattedDescription.append("<br>");
        }
        return formattedDescription.toString();
    }

    private void pdfButton() {
        // Generate PDF from WebView content
        String fileName = "Resume";
        File pdfFile = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName + ".pdf");

        // Calculate scale factor based on screen density
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        float density = displayMetrics.density;
        float scale = 1 / density; // Adjust this scale factor as needed

        // Calculate WebView content height
        webView.measure(View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        webView.layout(0, 0, webView.getMeasuredWidth(), webView.getMeasuredHeight());
        int webViewContentHeight = webView.getMeasuredHeight();

        try {
            PdfDocument pdfDocument = new PdfDocument();

            // Calculate PDF page size
            int webViewWidth = webView.getWidth();
            int webViewHeight = webViewContentHeight;
            int pageWidth = (int) Math.ceil(webViewWidth * scale);
            int pageHeight = (int) Math.ceil(webViewHeight * scale);

            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create();
            PdfDocument.Page page = pdfDocument.startPage(pageInfo);
            Canvas canvas = page.getCanvas();

            // Scale the canvas to match the scale factor
            canvas.scale(scale, scale);

            // Draw WebView content onto the canvas
            webView.draw(canvas);

            pdfDocument.finishPage(page);

            FileOutputStream outputStream = new FileOutputStream(pdfFile);
            pdfDocument.writeTo(outputStream);
            pdfDocument.close();
            outputStream.close();
            Toast.makeText(this, "PDF generated successfully", Toast.LENGTH_SHORT).show();

            // Open PDF using Intent
            Uri pdfUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".fileprovider", pdfFile);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(pdfUri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);

            Log.d(TAG, "PDF file path: " + pdfFile.getAbsolutePath());

            // Save the resume data to SharedPreferences if needed
            SharedPreferences sharedPreferences = getSharedPreferences("ResumeData", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("name", name);
            editor.putString("profileImageUri", profileImageUriString);
            editor.apply();

        } catch (IOException e) {
            Toast.makeText(this, "Failed to generate PDF: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void saveResumeToFile(String fileName, String name, String profileImageUri) {
        // Generate a unique filename based on resume details
        fileName = fileName.replaceAll("\\s+", "") + "_" + System.currentTimeMillis() + ".json";

        JSONObject resumeData = new JSONObject();
        try {
            // Check if name and profileImageUri are not null
            if (name != null) {
                resumeData.put("name", name);
            }
            if (profileImageUri != null) {
                resumeData.put("profileImageUri", profileImageUri);
            }

            // Construct the file path using getFilesDir() for internal storage
            File file = new File(getFilesDir(), fileName);

            // Write JSON data to file
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(resumeData.toString().getBytes());
                fos.flush();
                Toast.makeText(this, "Resume saved successfully", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to save resume", Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save resume", Toast.LENGTH_SHORT).show();
        }
    }

}