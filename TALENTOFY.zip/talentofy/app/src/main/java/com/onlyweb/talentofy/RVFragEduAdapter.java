package com.onlyweb.talentofy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.onlyweb.talentofy.FormFragments.EducationFragment;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

public class RVFragEduAdapter extends RecyclerView.Adapter<RVFragEduAdapter.EducationHolder> {

    private Context mContext;
    private ArrayList<EducationFragment.Education> educationList;
    private OnEducationRemovedListener onEducationRemovedListener;

    public interface OnEducationRemovedListener {
        void onEducationRemoved(int position);
    }

    public RVFragEduAdapter(Context context, ArrayList<EducationFragment.Education> experienceList, OnEducationRemovedListener listener) {
        this.mContext = context;
        if (educationList != null) {
            this.educationList = experienceList;
        } else {
            this.educationList = new ArrayList<>();
        }
        this.onEducationRemovedListener = listener;
    }

    @NonNull
    @Override
    public EducationHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.rv_frag_edu, parent, false);
        return new EducationHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EducationHolder holder, int position) {
        EducationFragment.Education education = educationList.get(position);
        holder.degreeEd.setText(education.getDegree());
        holder.universityEd.setText(education.getUniversity());
        holder.gradeEd.setText(education.getGrade());
        holder.yearEd.setText(education.getYear());
    }

    @Override
    public int getItemCount() {
        return educationList.size();
    }

    public class EducationHolder extends RecyclerView.ViewHolder {

        EditText degreeEd, universityEd, gradeEd, yearEd;
        Button btn_remove_edu;

        public EducationHolder(View itemView) {
            super(itemView);
            degreeEd = ((TextInputLayout) itemView.findViewById(R.id.form_edu_til_degree)).getEditText();
            universityEd = ((TextInputLayout) itemView.findViewById(R.id.form_edu_til_university)).getEditText();
            gradeEd = ((TextInputLayout) itemView.findViewById(R.id.form_edu_til_grade)).getEditText();
            yearEd = ((TextInputLayout) itemView.findViewById(R.id.form_edu_til_year)).getEditText();

            btn_remove_edu = itemView.findViewById(R.id.btn_remove_edu);
            btn_remove_edu.setOnClickListener(view -> {
                int pos = getAdapterPosition();
                educationList.remove(pos);
                notifyItemRemoved(pos);
                onEducationRemovedListener.onEducationRemoved(pos);
            });
        }
    }

    public void setEducationList(ArrayList<EducationFragment.Education> educationList) {
        if (educationList != null) {
            this.educationList = educationList;
        } else {
            this.educationList = new ArrayList<>();
        }
        notifyDataSetChanged();
    }
}
