package com.onlyweb.talentofy;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import model.Resume;

public class ResumeAdapter extends RecyclerView.Adapter<ResumeAdapter.ResumeViewHolder> {

    private List<Resume> resumeList;
    private OnResumeListener onResumeListener;

    public ResumeAdapter(List<Resume> resumeList, OnResumeListener onResumeListener) {
        this.resumeList = resumeList;
        this.onResumeListener = onResumeListener;
    }

    @NonNull
    @Override
    public ResumeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_resume, parent, false);
        return new ResumeViewHolder(view, onResumeListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ResumeViewHolder holder, int position) {
        Resume resume = resumeList.get(position);
        holder.name.setText(resume.getName());
        // Load profile picture using an image loading library such as Glide or Picasso
        // For example, using Glide:
        Glide.with(holder.itemView.getContext())
                .load(resume.getProfileImageUri())
                .into(holder.profilePicture);
    }

    @Override
    public int getItemCount() {
        return resumeList.size();
    }

    public static class ResumeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView name;
        public ImageView profilePicture;
        public Button btnEdit, btnDelete;
        OnResumeListener onResumeListener;

        public ResumeViewHolder(@NonNull View itemView, OnResumeListener onResumeListener) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            profilePicture = itemView.findViewById(R.id.profile_picture);
            btnEdit = itemView.findViewById(R.id.btn_edit);
            btnDelete = itemView.findViewById(R.id.btn_delete);
            this.onResumeListener = onResumeListener;

            btnEdit.setOnClickListener(this);
            btnDelete.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.btn_edit) {
                onResumeListener.onEditClick(getAdapterPosition());
            } else if (v.getId() == R.id.btn_delete) {
                onResumeListener.onDeleteClick(getAdapterPosition());
            }
        }
    }

    public interface OnResumeListener {
        void onEditClick(int position);
        void onDeleteClick(int position);
    }
}
