package com.onlyweb.talentofy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.List;

public class TemplateFragment extends Fragment {

    private ProgressBar progressBar;
    private RecyclerView templateRecyclerView;
    private RVTemplateAdapter adapter;
    private List<Template> templateList;
    private AdView adView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_template, container, false);

        // Initialize views
        progressBar = view.findViewById(R.id.progressBar);
        templateRecyclerView = view.findViewById(R.id.template_rv);
        adView = view.findViewById(R.id.adView);

        // Initialize the Mobile Ads SDK
        MobileAds.initialize(getContext(), initializationStatus -> {});

        // Create an ad request
        AdRequest adRequest = new AdRequest.Builder().build();

        // Set an AdListener to reload ads frequently
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                // Load a new ad when the current one is closed
                adView.loadAd(new AdRequest.Builder().build());
            }
        });

        // Start loading the ad in the background
        adView.loadAd(adRequest);

        // Initialize the template list and adapter
        templateList = new ArrayList<>();
        adapter = new RVTemplateAdapter(getContext(), templateList, this::onTemplateClick);

        // Set up RecyclerView
        templateRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        templateRecyclerView.setAdapter(adapter);

        // Load data into the RecyclerView
        loadTemplates();

        return view;
    }

    private void loadTemplates() {
        // Add templates with actual image resource IDs
        templateList.add(new Template(R.drawable.t1, "Template 1", "t1.html"));
        templateList.add(new Template(R.drawable.t2, "Template 2", "t2.html"));
        templateList.add(new Template(R.drawable.t3, "Template 3", "t3.html"));
        templateList.add(new Template(R.drawable.t4, "Template 4", "t4.html"));
        templateList.add(new Template(R.drawable.t5, "Template 5", "t5.html"));
        templateList.add(new Template(R.drawable.t6, "Template 6", "t6.html"));
        templateList.add(new Template(R.drawable.t7, "Template 7", "t7.html"));
        templateList.add(new Template(R.drawable.t8, "Template 8", "t8.html"));
        templateList.add(new Template(R.drawable.t9, "Template 9", "t9.html"));
        templateList.add(new Template(R.drawable.t10, "Template 10", "t10.html"));
        templateList.add(new Template(R.drawable.t11, "Template 11", "t11.html"));

        // Add more templates as needed

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        } else {
            // Log or handle the null case appropriately
            Log.e("TemplateFragment", "Adapter is null");
        }
        progressBar.setVisibility(View.GONE);
    }

    private void onTemplateClick(String htmlFileName) {
        // Check if any data is available
        if (!isDataAvailable()) {
            Toast.makeText(getContext(), "No data added. Please add your information before selecting a template.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(getActivity(), ViewCVActivity.class);
        intent.putExtra("HTML_FILE_NAME", htmlFileName);
        startActivity(intent);
    }

    private boolean isDataAvailable() {
        SharedPreferences personalSharedPreferences = getContext().getSharedPreferences("PersonalData", Context.MODE_PRIVATE);
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        // Check for personal details
        if (!personalSharedPreferences.getString("name", "").isEmpty() ||
                !personalSharedPreferences.getString("email", "").isEmpty() ||
                !personalSharedPreferences.getString("phone", "").isEmpty() ||
                !personalSharedPreferences.getString("address", "").isEmpty() ||
                !personalSharedPreferences.getString("linkedin", "").isEmpty() ||
                !personalSharedPreferences.getString("profession", "").isEmpty() ||
                !personalSharedPreferences.getString("profileImageUri", "").isEmpty()) {
            return true;
        }

        // Check for objective
        if (!sharedPreferences.getString("objective", "").isEmpty()) {
            return true;
        }

        // Check for skills
        if (!sharedPreferences.getString("skills", "").isEmpty()) {
            return true;
        }

        // Check for languages
        if (!sharedPreferences.getString("lang_key", "").isEmpty()) {
            return true;
        }

        // Check for projects
        if (!getContext().getSharedPreferences("ProjectData", Context.MODE_PRIVATE).getString("projectList", "").isEmpty()) {
            return true;
        }

        // Check for experience
        if (!getContext().getSharedPreferences("ExperienceData", Context.MODE_PRIVATE).getString("experienceList", "").isEmpty()) {
            return true;
        }

        // Check for education
        if (!getContext().getSharedPreferences("EducationData", Context.MODE_PRIVATE).getString("educationList", "").isEmpty()) {
            return true;
        }

        return false;
    }

    @Override
    public void onPause() {
        if (adView != null) {
            adView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adView != null) {
            adView.resume();
        }
    }

    @Override
    public void onDestroy() {
        if (adView != null) {
            adView.destroy();
        }
        super.onDestroy();
    }
}
