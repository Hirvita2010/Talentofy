package com.onlyweb.talentofy.FormFragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.onlyweb.talentofy.R;
import com.onlyweb.talentofy.RVFragExpAdapter;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class ExperienceFragment extends Fragment {

    private ArrayList<Experience> experienceList;
    private SharedPreferences sharedPreferences;
    private RVFragExpAdapter adapter;
    private Button nextButton;
    private RecyclerView recyclerView;
    private WebView webView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the main layout for this fragment
        View view = inflater.inflate(R.layout.fragment_experience, container, false);

        // Initialize the ArrayList
        experienceList = new ArrayList<>();
        sharedPreferences = requireActivity().getSharedPreferences("ExperienceData", Context.MODE_PRIVATE);

        // Initialize the WebView
       // webView = view.findViewById(R.id.webview);

        nextButton = view.findViewById(R.id.btn_next);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Experience Details Fragment
                SkillsFragment skillsFragment = new SkillsFragment();
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container, skillsFragment);
                transaction.addToBackStack(null); // Optional: Allows user to navigate back to EducationFragment
                transaction.commit();
            }
        });

        // Initialize the "Add" button
        Button addButton = view.findViewById(R.id.form_exp_btn_add);
        addButton.setOnClickListener(v -> showExperienceFormDialog());

        recyclerView = view.findViewById(R.id.container_exp_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new RVFragExpAdapter(getContext(), experienceList, position -> saveExperienceDataToSharedPreferences());
        recyclerView.setAdapter(adapter);

        loadExperienceDataFromSharedPreferences(); // Load data from SharedPreferences

        return view;
    }

    private void showExperienceFormDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.form_frag_exp, null);

        final TextInputEditText companyEx = view.findViewById(R.id.form_exp_et_company);
        final TextInputEditText jobEx = view.findViewById(R.id.form_exp_et_job);
        final TextInputEditText sdateEx = view.findViewById(R.id.form_exp_et_sdate);
        final TextInputEditText edateEx = view.findViewById(R.id.form_exp_et_edate);
        final TextInputEditText descEx = view.findViewById(R.id.form_exp_et_desc);

        builder.setView(view)
                .setTitle("Add Experience")
                .setNeutralButton("Cancel", null)
                .setPositiveButton("Add", (dialogInterface, i) -> {
                    String company = companyEx.getText().toString();
                    String job = jobEx.getText().toString();
                    String sdate = sdateEx.getText().toString();
                    String edate = edateEx.getText().toString();
                    String desc = descEx.getText().toString();

                    Experience experienceNew = new Experience(company, job, sdate, edate, desc);
                    experienceList.add(experienceNew);
                    saveExperienceDataToSharedPreferences(); // Save data to SharedPreferences

                    adapter.notifyDataSetChanged(); // Update RecyclerView

                    Toast.makeText(getContext(), "Data added", Toast.LENGTH_SHORT).show();
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void saveExperienceDataToSharedPreferences() {
        Gson gson = new Gson();
        String json = gson.toJson(experienceList);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("experienceList", json);
        editor.apply();
    }

    private void loadExperienceDataFromSharedPreferences() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString("experienceList", null);
        Type type = new TypeToken<ArrayList<Experience>>() {}.getType();
        experienceList = gson.fromJson(json, type);

        if (experienceList == null) {
            experienceList = new ArrayList<>();
        }

        adapter.setExperienceList(experienceList);
        adapter.notifyDataSetChanged(); // Update RecyclerView
    }

    public static class Experience {
        private String company;
        private String job;
        private String sdate;
        private String edate;
        private String desc;

        public Experience(String company, String job, String sdate, String edate, String desc) {
            this.company = company;
            this.job = job;
            this.sdate = sdate;
            this.edate = edate;
            this.desc = desc;
        }

        public String getCompany() { return company; }
        public String getJob() { return job; }
        public String getSdate() { return sdate; }
        public String getEdate() { return edate; }
        public String getDesc() { return desc; }
    }
}
