package com.onlyweb.talentofy;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.IOException;

public class ProfileFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private FirebaseUser currentUser;

    private ImageView ivProfileImage;
    private TextView tvUsername, tvEmail, tvPhone;
    private Button btnDeleteAccount;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        currentUser = mAuth.getCurrentUser();

        ivProfileImage = view.findViewById(R.id.ivProfileImage);
        tvUsername = view.findViewById(R.id.tvUsername);
        tvEmail = view.findViewById(R.id.tvEmail);
        tvPhone = view.findViewById(R.id.tvPhone);
        btnDeleteAccount = view.findViewById(R.id.btnDeleteAccount);
        CardView cvProfileImage = view.findViewById(R.id.cvProfileImage);

        cvProfileImage.setOnClickListener(v -> showImagePickerDialog());

        fetchUserProfile();

        btnDeleteAccount.setOnClickListener(v -> {
            new AlertDialog.Builder(getActivity())
                    .setTitle("Delete Account")
                    .setMessage("Are you sure you want to delete your account permanently?")
                    .setPositiveButton("Yes", (dialog, which) -> deleteUserAccount())
                    .setNegativeButton("No", null)
                    .show();
        });

        return view;
    }

    private void showImagePickerDialog() {
        new AlertDialog.Builder(getActivity())
                .setTitle("Change Profile Picture")
                .setMessage("Do you want to select a new profile picture?")
                .setPositiveButton("Select", (dialog, which) -> openImagePicker())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == getActivity().RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);
                // Show dialog to confirm image selection
                new AlertDialog.Builder(getActivity())
                        .setTitle("Confirm Profile Picture")
                        .setMessage("Do you want to use this image as your profile picture?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            ivProfileImage.setImageBitmap(bitmap);
                            // Save the profile image URL
                            saveProfileImageUrl(imageUri.toString());
                        })
                        .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                        .show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveProfileImageUrl(String imageUrl) {
        if (currentUser != null) {
            String userId = currentUser.getUid();
            db.collection("users").document(userId).update("ProfileImageUrl", imageUrl)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(getActivity(), "Profile image updated.", Toast.LENGTH_SHORT).show();
                        // Save the profile image URL to SharedPreferences
                        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("userPrefs", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("profileImageUrl", imageUrl);
                        editor.apply();

                        // Update navigation header profile image in MainActivity
                        ((MainPageActivity) getActivity()).updateNavHeaderProfileImage(imageUrl);
                    })
                    .addOnFailureListener(exception -> {
                        Toast.makeText(getActivity(), "Failed to update profile image URL.", Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void fetchUserProfile() {
        if (currentUser != null) {
            String userId = currentUser.getUid();
            db.collection("users").document(userId).get().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        String username = document.getString("Username");
                        String email = document.getString("Email");
                        String phone = document.getString("Phone");
                        String profileImageUrl = document.getString("ProfileImageUrl");

                        tvUsername.setText(username);
                        tvEmail.setText(email);
                        tvPhone.setText(phone);

                        if (profileImageUrl != null) {
                            Glide.with(this).load(profileImageUrl).into(ivProfileImage);
                        }

                        // Save user data to SharedPreferences
                        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("userPrefs", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("username", username);
                        editor.putString("email", email);
                        editor.putString("phone", phone);
                        editor.putString("profileImageUrl", profileImageUrl);
                        editor.apply();
                    }
                } else {
                    Toast.makeText(getActivity(), "Failed to fetch user data.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void deleteUserAccount() {
        if (currentUser != null) {
            String userId = currentUser.getUid();

            // First, delete the user data from Firestore
            db.collection("users").document(userId).get().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        String profileImageUrl = document.getString("ProfileImageUrl");

                        // Delete the user document
                        db.collection("users").document(userId).delete().addOnCompleteListener(task1 -> {
                            if (task1.isSuccessful()) {
                                // If there's a profile image URL, delete the image from Firebase Storage
                                if (profileImageUrl != null && !profileImageUrl.isEmpty()) {
                                    deleteProfileImage(profileImageUrl);
                                }

                                // Delete the user account from Firebase Authentication
                                currentUser.delete().addOnCompleteListener(task2 -> {
                                    if (task2.isSuccessful()) {
                                        Toast.makeText(getActivity(), "Account deleted successfully.", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getActivity(), RegisterPageActivity.class);
                                        startActivity(intent);
                                        getActivity().finish();
                                    } else {
                                        Toast.makeText(getActivity(), "Failed to delete account.", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            } else {
                                Toast.makeText(getActivity(), "Failed to delete user data.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } else {
                    Toast.makeText(getActivity(), "Failed to fetch user data.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void deleteProfileImage(String profileImageUrl) {
        // Extract the path from the URL
        StorageReference photoRef = FirebaseStorage.getInstance().getReferenceFromUrl(profileImageUrl);

        // Delete the file
        photoRef.delete().addOnSuccessListener(aVoid -> {
            Toast.makeText(getActivity(), "Profile image deleted.", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(exception -> {
            Toast.makeText(getActivity(), "Failed to delete profile image.", Toast.LENGTH_SHORT).show();
        });
    }
}
