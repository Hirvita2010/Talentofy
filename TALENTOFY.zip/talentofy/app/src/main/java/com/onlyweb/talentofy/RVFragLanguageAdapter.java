package com.onlyweb.talentofy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.onlyweb.talentofy.FormFragments.LanguageFragment;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class RVFragLanguageAdapter extends RecyclerView.Adapter<RVFragLanguageAdapter.LanguageHolder> {

    private Context mContext;
    private ArrayList<LanguageFragment.Language> languageList;

    // Constructor for the Class
    public RVFragLanguageAdapter(Context context, ArrayList<LanguageFragment.Language> languageList) {
        this.mContext = context;
        this.languageList = languageList;
    }

    @NonNull
    @Override
    public LanguageHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        // Inflate the layout view you have created for the list rows here
        View view = layoutInflater.inflate(R.layout.rv_frag_lang, parent, false);
        return new LanguageHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LanguageHolder holder, int position) {
        // Bind data to the views here
        LanguageFragment.Language language = languageList.get(position);
        holder.langEt.setText(language.getLanguage());
    }

    @Override
    public int getItemCount() {
        return languageList.size();
    }

    // This is your ViewHolder class that helps to populate data to the view
    public class LanguageHolder extends RecyclerView.ViewHolder {

        TextInputEditText langEt;
        Button btnRemoveLang;

        public LanguageHolder(View itemView) {
            super(itemView);
            langEt = itemView.findViewById(R.id.form_lang_et_lang);
            btnRemoveLang = itemView.findViewById(R.id.btn_remove_lang);

            btnRemoveLang.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        languageList.remove(pos);
                        notifyItemRemoved(pos);
                        notifyItemRangeChanged(pos, languageList.size());
                    }
                }
            });
        }
    }
}
