package com.onlyweb.talentofy.FormFragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputEditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.onlyweb.talentofy.R;

public class ObjectiveFragment extends Fragment {

    private Button saveButton;
    private Button nextButton;
    private TextInputEditText objectiveEditText;
    private TextView displayTextView;
    private static final String OBJECTIVE_KEY = "objective";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_objective, container, false);

        saveButton = view.findViewById(R.id.form_obj_btn_save);
        nextButton = view.findViewById(R.id.btn_next);
        objectiveEditText = view.findViewById(R.id.form_obj_et_obj);
        displayTextView = view.findViewById(R.id.form_obj_tv_display);

        saveButton.setOnClickListener(v -> saveObjectiveToSharedPreferences());
        nextButton.setOnClickListener(v -> navigateToNextFragment());

        loadObjectiveFromSharedPreferences();

        return view;
    }

    private void saveObjectiveToSharedPreferences() {
        String enteredText = objectiveEditText.getText().toString();
       // displayTextView.setText(enteredText);
        //displayTextView.setVisibility(View.VISIBLE);

        SharedPreferences sharedPref = requireActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(OBJECTIVE_KEY, enteredText);
        editor.apply();
    }

    private void loadObjectiveFromSharedPreferences() {
        SharedPreferences sharedPref = requireActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String objective = sharedPref.getString(OBJECTIVE_KEY, "");

        if (!objective.isEmpty()) {
         //   displayTextView.setText(objective);
           // displayTextView.setVisibility(View.VISIBLE);
        }
    }

    private void navigateToNextFragment() {
        SharedPreferences sharedPref = requireActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String objective = sharedPref.getString(OBJECTIVE_KEY, "");

        Bundle bundle = new Bundle();
        bundle.putString(OBJECTIVE_KEY, objective);

        ProjectsFragment projectFragment = new ProjectsFragment();
        projectFragment.setArguments(bundle);

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, projectFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
