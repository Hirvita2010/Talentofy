package com.onlyweb.talentofy.FormFragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.onlyweb.talentofy.R;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PersonalFragment extends Fragment {

    private static final int PICK_IMAGE = 1;
    private EditText nameEditText, emailEditText, phoneEditText, addressEditText, linkedinEditText, professionEditText;
    private ImageView profileImageView;
    private Uri profileImageUri = null;
    private SharedPreferences sharedPreferences;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_personal, container, false);
        nameEditText = view.findViewById(R.id.p_name);
        emailEditText = view.findViewById(R.id.p_email);
        phoneEditText = view.findViewById(R.id.p_phone);
        addressEditText = view.findViewById(R.id.p_address);
        professionEditText = view.findViewById(R.id.p_profession);
        linkedinEditText = view.findViewById(R.id.p_linkdin);

        profileImageView = view.findViewById(R.id.profile);
        Button nextButton = view.findViewById(R.id.btn_next);
        sharedPreferences = requireActivity().getSharedPreferences("PersonalData", Context.MODE_PRIVATE);

        profileImageView.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
        });

        nextButton.setOnClickListener(v -> {
            if (validateInput()) {
                savePersonalDataToSharedPreferences();
                EducationFragment educationFragment = new EducationFragment();
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container, educationFragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == getActivity().RESULT_OK && data != null && data.getData() != null) {
            profileImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), profileImageUri);
                profileImageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean validateInput() {
        String name = nameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String address = addressEditText.getText().toString().trim();


        if (name.isEmpty()) {
            Toast.makeText(getActivity(), "Please enter your full name.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!isValidEmail(email)) {
            Toast.makeText(getActivity(), "Please enter a valid email address.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!isValidPhoneNumber(phone)) {
            Toast.makeText(getActivity(), "Please enter a valid 10-digit phone number.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (address.isEmpty()) {
            Toast.makeText(getActivity(), "Please enter your address.", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Additional validation logic for other fields if needed...

        return true;
    }

    private boolean isValidPhoneNumber(String phone) {
        return phone != null && phone.length() == 10 && phone.matches("\\d{10}");
    }

    private boolean isValidEmail(String email) {
        String emailPattern = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        Pattern pattern = Pattern.compile(emailPattern);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private void savePersonalDataToSharedPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("name", nameEditText.getText().toString().trim());
        editor.putString("email", emailEditText.getText().toString().trim());
        editor.putString("phone", phoneEditText.getText().toString().trim());
        editor.putString("address", addressEditText.getText().toString().trim());
        editor.putString("profession", professionEditText.getText().toString().trim());
        editor.putString("linkedin", linkedinEditText.getText().toString().trim());
        if (profileImageUri != null) {
            editor.putString("profileImageUri", profileImageUri.toString());
        }
        editor.apply();
    }
}
