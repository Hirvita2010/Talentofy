package com.onlyweb.talentofy;

public class Template {
    private int imageResId;
    private String name;
    private String htmlFileName;

    public Template(int imageResId, String name, String htmlFileName) {
        this.imageResId = imageResId;
        this.name = name;
        this.htmlFileName = htmlFileName;
    }

    public int getImageResId() {
        return imageResId;
    }

    public String getName() {
        return name;
    }

    public String getHtmlFileName() {
        return htmlFileName;
    }
}
