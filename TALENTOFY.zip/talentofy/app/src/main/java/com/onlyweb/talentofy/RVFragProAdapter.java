package com.onlyweb.talentofy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.onlyweb.talentofy.FormFragments.ProjectsFragment;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class RVFragProAdapter extends RecyclerView.Adapter<RVFragProAdapter.ProjectsHolder> {

    private Context mContext;
    private ArrayList<ProjectsFragment.Projects> projectsList;
    private OnProjectRemovedListener onProjectRemovedListener;

    public interface OnProjectRemovedListener {
        void onProjectRemoved(int position);
    }

    public RVFragProAdapter(Context context, ArrayList<ProjectsFragment.Projects> projectsList, OnProjectRemovedListener listener) {
        this.mContext = context;
        this.projectsList = projectsList;
        this.onProjectRemovedListener = listener;
    }

    @NonNull
    @Override
    public ProjectsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.rv_frag_project, parent, false);
        return new ProjectsHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProjectsHolder holder, int position) {
        ProjectsFragment.Projects project = projectsList.get(position);
        // Check if the title is a placeholder, if so, set an empty string
        holder.titlePro.setText(project.getTitle().equals("{TITLE}") ? "" : project.getTitle());
        // Check if the description is a placeholder, if so, set an empty string
        holder.descPro.setText(project.getDesc().equals("{DESCRIPTION}") ? "" : project.getDesc());
    }

    @Override
    public int getItemCount() {
        return projectsList.size();
    }

    public class ProjectsHolder extends RecyclerView.ViewHolder {

        TextInputEditText titlePro, descPro;
        Button btn_remove_pro;

        public ProjectsHolder(View itemView) {
            super(itemView);
            titlePro = itemView.findViewById(R.id.form_pro_et_title);
            descPro = itemView.findViewById(R.id.form_pro_et_desc);

            btn_remove_pro = itemView.findViewById(R.id.btn_remove_pro);
            btn_remove_pro.setOnClickListener(view -> {
                int pos = getAdapterPosition();
                projectsList.remove(pos);
                notifyItemRemoved(pos);
                onProjectRemovedListener.onProjectRemoved(pos);
            });
        }
    }

    public void setProjectsList(ArrayList<ProjectsFragment.Projects> projectsList) {
        this.projectsList = projectsList;
        notifyDataSetChanged();
    }
}
