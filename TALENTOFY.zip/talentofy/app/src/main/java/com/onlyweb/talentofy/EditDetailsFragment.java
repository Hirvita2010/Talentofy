package com.onlyweb.talentofy;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.onlyweb.talentofy.FormFragments.EducationFragment;
import com.onlyweb.talentofy.FormFragments.ExperienceFragment;
import com.onlyweb.talentofy.FormFragments.LanguageFragment;
import com.onlyweb.talentofy.FormFragments.ObjectiveFragment;
import com.onlyweb.talentofy.FormFragments.PersonalFragment;
import com.onlyweb.talentofy.FormFragments.ProjectsFragment;
import com.onlyweb.talentofy.FormFragments.SkillsFragment;

public class EditDetailsFragment extends Fragment {

    private static final String ARG_RESUME_NAME = "resume_name";
    private static final String ARG_PROFILE_IMAGE_URI = "profile_image_uri";

    private Button btnPersonal, btnEducation, btnExperience, btnSkills, btnProjects, btnObjective, btnLanguage;
    private AdView adView;

    public static EditDetailsFragment newInstance(String name, String profileImageUri) {
        EditDetailsFragment fragment = new EditDetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_RESUME_NAME, name);
        args.putString(ARG_PROFILE_IMAGE_URI, profileImageUri);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_edit_details, container, false);

        // Initialize buttons
        btnPersonal = view.findViewById(R.id.btn_personal_detail);
        btnProjects = view.findViewById(R.id.btn_project_detail);
        btnEducation = view.findViewById(R.id.btn_educational_detail);
        btnExperience = view.findViewById(R.id.btn_experience_detail);
        btnSkills = view.findViewById(R.id.btn_skill_detail);
        btnObjective = view.findViewById(R.id.btn_objective_detail);
        btnLanguage = view.findViewById(R.id.btn_language_detail);

        // Set click listeners
        btnPersonal.setOnClickListener(v -> addFormFragment("frag_per"));
        btnEducation.setOnClickListener(v -> addFormFragment("frag_edu"));
        btnExperience.setOnClickListener(v -> addFormFragment("frag_exp"));
        btnSkills.setOnClickListener(v -> addFormFragment("frag_skill"));
        btnObjective.setOnClickListener(v -> addFormFragment("frag_obj"));
        btnProjects.setOnClickListener(v -> addFormFragment("frag_pro"));
        btnLanguage.setOnClickListener(v -> addFormFragment("frag_lang"));

        // Initialize the Mobile Ads SDK
        MobileAds.initialize(getContext(), initializationStatus -> {});

        // Find AdView and load an ad
        adView = view.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        // Set an AdListener to reload ads frequently
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                // Load a new ad when the current one is closed
                adView.loadAd(new AdRequest.Builder().build());
            }
        });

        return view;
    }

    @Override
    public void onPause() {
        if (adView != null) {
            adView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adView != null) {
            adView.resume();
        }
    }

    @Override
    public void onDestroy() {
        if (adView != null) {
            adView.destroy();
        }
        super.onDestroy();
    }

    protected void addFormFragment(String fragName) {
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        Fragment fragment = null;
        switch (fragName) {
            case "frag_per":
                fragment = new PersonalFragment();
                break;
            case "frag_edu":
                fragment = new EducationFragment();
                break;
            case "frag_exp":
                fragment = new ExperienceFragment();
                break;
            case "frag_skill":
                fragment = new SkillsFragment();
                break;
            case "frag_obj":
                fragment = new ObjectiveFragment();
                break;
            case "frag_pro":
                fragment = new ProjectsFragment();
                break;
            case "frag_lang":
                fragment = new LanguageFragment();
                break;
            default:
                if (getContext() != null) {
                    Toast.makeText(getContext(), "addFormFragment() not Working!", Toast.LENGTH_SHORT).show();
                }
                return;
        }

        if (fragment != null) {
            transaction.replace(R.id.container_main, fragment); // Ensure this ID matches the container in MainActivity
            transaction.addToBackStack(null);
            transaction.commit();

            // Notify MainActivity to hide the bottom navigation and FAB if a sub-fragment is shown
            ((MainActivity) requireActivity()).setBottomNavigationVisibility(true); // Hides the bottom navigation and FAB
        }
    }
}
