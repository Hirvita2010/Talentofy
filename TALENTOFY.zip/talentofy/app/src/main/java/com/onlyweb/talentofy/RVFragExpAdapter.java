package com.onlyweb.talentofy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.onlyweb.talentofy.FormFragments.ExperienceFragment;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

public class RVFragExpAdapter extends RecyclerView.Adapter<RVFragExpAdapter.ExperienceHolder> {

    private Context mContext;
    private ArrayList<ExperienceFragment.Experience> experienceList;
    private OnExperienceRemovedListener onExperienceRemovedListener;

    public interface OnExperienceRemovedListener {
        void onExperienceRemoved(int position);
    }

    public RVFragExpAdapter(Context context, ArrayList<ExperienceFragment.Experience> experienceList, OnExperienceRemovedListener listener) {
        this.mContext = context;
        if (experienceList != null) {
            this.experienceList = experienceList;
        } else {
            this.experienceList = new ArrayList<>();
        }
        this.onExperienceRemovedListener = listener;
    }

    @NonNull
    @Override
    public ExperienceHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.rv_frag_exp, parent, false);
        return new ExperienceHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExperienceHolder holder, int position) {
        ExperienceFragment.Experience experience = experienceList.get(position);
        holder.companyEx.setText(experience.getCompany());
        holder.jobEx.setText(experience.getJob());
        holder.sdateEx.setText(experience.getSdate());
        holder.edateEx.setText(experience.getEdate());
        holder.descEx.setText(experience.getDesc());
    }

    @Override
    public int getItemCount() {
        return experienceList.size();
    }

    public class ExperienceHolder extends RecyclerView.ViewHolder {

        EditText companyEx, jobEx, descEx, sdateEx, edateEx;
        Button btn_remove_exp;

        public ExperienceHolder(View itemView) {
            super(itemView);
            companyEx = ((TextInputLayout) itemView.findViewById(R.id.form_exp_til_company)).getEditText();
            jobEx = ((TextInputLayout) itemView.findViewById(R.id.form_exp_til_job)).getEditText();
            sdateEx = ((TextInputLayout) itemView.findViewById(R.id.form_exp_til_sdate)).getEditText();
            edateEx = ((TextInputLayout) itemView.findViewById(R.id.form_exp_til_edate)).getEditText();
            descEx = ((TextInputLayout) itemView.findViewById(R.id.form_exp_til_desc)).getEditText();

            btn_remove_exp = itemView.findViewById(R.id.btn_remove_exp);
            btn_remove_exp.setOnClickListener(view -> {
                int pos = getAdapterPosition();
                experienceList.remove(pos);
                notifyItemRemoved(pos);
                onExperienceRemovedListener.onExperienceRemoved(pos);
            });
        }
    }

    public void setExperienceList(ArrayList<ExperienceFragment.Experience> experienceList) {
        if (experienceList != null) {
            this.experienceList = experienceList;
        } else {
            this.experienceList = new ArrayList<>();
        }
        notifyDataSetChanged();
    }
}
