package com.onlyweb.talentofy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RVTemplateAdapter extends RecyclerView.Adapter<RVTemplateAdapter.TemplateViewHolder> {

    private Context context;
    private List<Template> templateList;
    private OnTemplateClickListener onTemplateClickListener;

    public RVTemplateAdapter(Context context, List<Template> templateList, OnTemplateClickListener onTemplateClickListener) {
        this.context = context;
        this.templateList = templateList;
        this.onTemplateClickListener = onTemplateClickListener;
    }

    @NonNull
    @Override
    public TemplateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.grid_item, parent, false);
        return new TemplateViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TemplateViewHolder holder, int position) {
        Template template = templateList.get(position);
        holder.templateImageView.setImageResource(template.getImageResId());
        holder.itemView.setOnClickListener(v -> onTemplateClickListener.onTemplateClick(template.getHtmlFileName()));
    }

    @Override
    public int getItemCount() {
        return templateList.size();
    }

    public static class TemplateViewHolder extends RecyclerView.ViewHolder {
        ImageView templateImageView;

        public TemplateViewHolder(@NonNull View itemView) {
            super(itemView);
            templateImageView = itemView.findViewById(R.id.template_img);
        }
    }

    public interface OnTemplateClickListener {
        void onTemplateClick(String htmlFileName);
    }
}
