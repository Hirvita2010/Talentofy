package com.onlyweb.talentofy;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.AdListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import model.Resume;

public class HomeFragment extends Fragment implements ResumeAdapter.OnResumeListener {

    private static final String TAG = "HomeFragment";
    private NativeAdView nativeAdView;
    private RecyclerView recyclerView;
    private ResumeAdapter adapter;
    private List<Resume> resumeList;
    private static final String DELETED_RESUMES_PREF = "deleted_resumes_pref";
    private static final String DELETED_RESUMES_KEY = "deleted_resumes_key";

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        nativeAdView = view.findViewById(R.id.native_ad_view);
        recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        loadNativeAd(); // Load native ad
        loadResumeData(); // Load resume data

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadNativeAd();
    }

    private void loadNativeAd() {
        AdLoader adLoader = new AdLoader.Builder(requireContext(), "ca-app-pub-9405167098279820/3461930686")
                .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(@NonNull NativeAd nativeAd) {
                        Log.d(TAG, "Native ad loaded.");
                        populateNativeAdView(nativeAd, nativeAdView);
                    }
                })
                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        Log.e(TAG, "Failed to load native ad: " + loadAdError.getMessage());
                    }
                })
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());

        NativeAd.Image icon = nativeAd.getIcon();
        if (icon == null) {
            adView.getIconView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(icon.getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
    }

    private void loadResumeData() {
        resumeList = new ArrayList<>();

        // Get the directory where resume JSON files are stored
        File directory = new File(requireContext().getFilesDir().getAbsolutePath());

        // List all files in the directory
        File[] files = directory.listFiles();

        if (files != null) {
            Log.d(TAG, "Number of files found: " + files.length);
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".json")) {
                    try {
                        Log.d(TAG, "Reading file: " + file.getName());

                        // Read JSON data from file
                        FileInputStream fis = requireContext().openFileInput(file.getName());
                        InputStreamReader isr = new InputStreamReader(fis);
                        BufferedReader bufferedReader = new BufferedReader(isr);
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            sb.append(line);
                        }
                        fis.close();

                        // Log JSON content before parsing
                        String jsonContent = sb.toString();
                        Log.d(TAG, "JSON Content: " + jsonContent);

                        // Parse JSON data
                        JSONObject jsonObject = new JSONObject(jsonContent);
                        String name = jsonObject.optString("name", "");
                        String profileImageUriString = jsonObject.optString("profileImageUri", "");

                        Log.d(TAG, "Parsed name: " + name);
                        Log.d(TAG, "Parsed profile image URI: " + profileImageUriString);

                        // Add resume data to list if not marked as deleted
                        if (!isResumeDeleted(name)) {
                            Uri profileImageUri = Uri.parse(profileImageUriString);
                            resumeList.add(new Resume(name, profileImageUri));
                        }

                    } catch (FileNotFoundException e) {
                        Log.e(TAG, "File not found: " + file.getName());
                    } catch (IOException e) {
                        Log.e(TAG, "IOException while reading file: " + e.getMessage());
                    } catch (JSONException e) {
                        Log.e(TAG, "Error parsing JSON: " + e.getMessage());
                    }
                }
            }
        } else {
            Log.d(TAG, "No files found in directory: " + directory.getAbsolutePath());
        }

        // Initialize and set adapter
        adapter = new ResumeAdapter(resumeList, this);
        recyclerView.setAdapter(adapter);
    }

    private boolean isResumeDeleted(String name) {
        Set<String> deletedResumes = getDeletedResumes();
        return deletedResumes.contains(name);
    }

    private Set<String> getDeletedResumes() {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences(DELETED_RESUMES_PREF, Context.MODE_PRIVATE);
        return sharedPreferences.getStringSet(DELETED_RESUMES_KEY, new HashSet<>());
    }

    private void saveDeletedResume(String name) {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences(DELETED_RESUMES_PREF, Context.MODE_PRIVATE);
        Set<String> deletedResumes = sharedPreferences.getStringSet(DELETED_RESUMES_KEY, new HashSet<>());
        deletedResumes.add(name);
        sharedPreferences.edit().putStringSet(DELETED_RESUMES_KEY, deletedResumes).apply();
    }

    private void deleteResumeFile(String fileName) {
        File directory = new File(requireContext().getFilesDir().getAbsolutePath());
        File file = new File(directory, fileName);
        if (file.exists()) {
            boolean deleted = file.delete();
            Log.d(TAG, "Resume file deleted: " + deleted);
        }
    }

    @Override
    public void onEditClick(int position) {
        // Handle edit action here
        // Example: Open Edit Fragment or Activity
        Resume selectedResume = resumeList.get(position);
        // Implement your edit action
    }

    @Override
    public void onDeleteClick(int position) {
        if (position >= 0 && position < resumeList.size()) {
            String fileName = resumeList.get(position).getName() + ".json";
            deleteResumeFile(fileName);
            saveDeletedResume(resumeList.get(position).getName());
            resumeList.remove(position);
            adapter.notifyItemRemoved(position);
        } else {
            Log.e(TAG, "Invalid position for delete operation: " + position);
        }
    }
}
