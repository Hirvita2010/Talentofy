    package com.onlyweb.talentofy.FormFragments;

    import android.content.Context;
    import android.content.SharedPreferences;
    import android.os.Bundle;
    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.widget.Button;
    import android.widget.Toast;

    import androidx.annotation.NonNull;
    import androidx.annotation.Nullable;
    import androidx.appcompat.app.AlertDialog;
    import androidx.fragment.app.Fragment;
    import androidx.fragment.app.FragmentTransaction;
    import androidx.recyclerview.widget.LinearLayoutManager;
    import androidx.recyclerview.widget.RecyclerView;

    import com.onlyweb.talentofy.TemplateFragment;
    import com.google.android.material.textfield.TextInputEditText;
    import com.onlyweb.talentofy.R;
    import com.onlyweb.talentofy.RVFragProAdapter;
    import com.google.gson.Gson;
    import com.google.gson.reflect.TypeToken;

    import java.lang.reflect.Type;
    import java.util.ArrayList;

    public class ProjectsFragment extends Fragment implements RVFragProAdapter.OnProjectRemovedListener {

        private ArrayList<Projects> projects;
        private RVFragProAdapter adapter;
        private SharedPreferences sharedPreferences;

        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_projects, container, false);

            // Initialize the projects list and shared preferences
            projects = new ArrayList<>();
            sharedPreferences = requireActivity().getSharedPreferences("ProjectData", Context.MODE_PRIVATE);
            loadProjectsFromSharedPreferences();

            // Set up the RecyclerView
            RecyclerView recyclerView = view.findViewById(R.id.container_project_list);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            adapter = new RVFragProAdapter(getContext(), projects, this);
            recyclerView.setAdapter(adapter);

            // Set up the Add Project button
            Button addButton = view.findViewById(R.id.form_pro_btn_add);
            addButton.setOnClickListener(v -> showProjectFormDialog());

            // Set up the Select Template button
            Button selectTemplateButton = view.findViewById(R.id.btn_select_temp);
            selectTemplateButton.setOnClickListener(v -> navigateToTemplateFragment());

            return view;
        }

        private void showProjectFormDialog() {
            AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
            LayoutInflater inflater = requireActivity().getLayoutInflater();
            View view = inflater.inflate(R.layout.form_frag_pro, null);

            final TextInputEditText titlePro = view.findViewById(R.id.form_pro_et_title);
            final TextInputEditText descPro = view.findViewById(R.id.form_pro_et_desc);

            builder.setView(view)
                    .setTitle("Add Project")
                    .setNeutralButton("Cancel", null)
                    .setPositiveButton("Add", (dialogInterface, i) -> {
                        String title = titlePro.getText().toString();
                        String desc = descPro.getText().toString();
                        Projects projectNew = new Projects(title, desc);
                        projects.add(projectNew);
                        adapter.notifyItemInserted(projects.size() - 1);
                        saveProjectsToSharedPreferences();
                        Toast.makeText(getContext(), "Data added", Toast.LENGTH_SHORT).show();
                    });

            AlertDialog dialog = builder.create();
            dialog.show();
        }

        private void navigateToTemplateFragment() {
            Fragment templateFragment = new TemplateFragment();
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.replace(R.id.container, templateFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        }

        @Override
        public void onProjectRemoved(int position) {
            if (position >= 0 && position < projects.size()) {
                projects.remove(position);
                adapter.notifyItemRemoved(position);
                saveProjectsToSharedPreferences();
                Toast.makeText(getContext(), "Project removed", Toast.LENGTH_SHORT).show();
            }
        }

        private void saveProjectsToSharedPreferences() {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            Gson gson = new Gson();
            String json = gson.toJson(projects);
            editor.putString("projectList", json);
            editor.apply();
        }

        private void loadProjectsFromSharedPreferences() {
            String json = sharedPreferences.getString("projectList", "");
            if (!json.isEmpty()) {
                Gson gson = new Gson();
                Type type = new TypeToken<ArrayList<Projects>>() {}.getType();
                projects = gson.fromJson(json, type);
            }
        }

        public static class Projects {
            private String title;
            private String desc;

            public Projects(String title, String desc) {
                this.title = title;
                this.desc = desc;
            }

            public String getTitle() {
                return title;
            }

            public String getDesc() {
                return desc;
            }
        }
    }
