package com.onlyweb.talentofy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.onlyweb.talentofy.FormFragments.SkillsFragment;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class RVFragSkillAdapter extends RecyclerView.Adapter<RVFragSkillAdapter.SkillsHolder> {

    private Context mContext;
    private ArrayList<SkillsFragment.Skill> skillsList;

    // Constructor for the Class
    public RVFragSkillAdapter(Context context, ArrayList<SkillsFragment.Skill> skillsList) {
        this.mContext = context;
        this.skillsList = skillsList;
    }

    @NonNull
    @Override
    public SkillsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        // Inflate the layout view you have created for the list rows here
        View view = layoutInflater.inflate(R.layout.rv_frag_skill, parent, false);
        return new SkillsHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SkillsHolder holder, int position) {
        // Bind data to the views here
        SkillsFragment.Skill skill = skillsList.get(position);
        holder.skillEt.setText(skill.getSkillName());
    }

    @Override
    public int getItemCount() {
        return skillsList.size();
    }

    // This is your ViewHolder class that helps to populate data to the view
    public class SkillsHolder extends RecyclerView.ViewHolder {

        TextInputEditText skillEt;
        Button btnRemoveSkill;

        public SkillsHolder(View itemView) {
            super(itemView);
            skillEt = itemView.findViewById(R.id.form_skill_et_skill);
            btnRemoveSkill = itemView.findViewById(R.id.btn_remove_skill);

            btnRemoveSkill.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        skillsList.remove(pos);
                        notifyItemRemoved(pos);
                        notifyItemRangeChanged(pos, skillsList.size());
                    }
                }
            });
        }
    }
}
