package com.onlyweb.talentofy.FormFragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.onlyweb.talentofy.R;
import com.onlyweb.talentofy.RVFragEduAdapter;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class EducationFragment extends Fragment {

    private static final String PREF_NAME = "EducationData";
    private static final String KEY_EDUCATION_LIST = "educationList";

    private ArrayList<Education> educationList;
    private SharedPreferences sharedPreferences;
    private RVFragEduAdapter adapter;
    private Button nextButton;
    private RecyclerView recyclerView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_education, container, false);

        // Initialize the ArrayList
        educationList = new ArrayList<>();
        sharedPreferences = requireActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        nextButton = view.findViewById(R.id.btn_next);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Experience Fragment
                ExperienceFragment experienceFragment = new ExperienceFragment();
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container, experienceFragment);
                transaction.addToBackStack(null); // Optional: Allows user to navigate back to EducationFragment
                transaction.commit();
            }
        });

        // Initialize the "Add" button
        Button addButton = view.findViewById(R.id.edu_btn_add);
        addButton.setOnClickListener(v -> showEducationFormDialog());

        recyclerView = view.findViewById(R.id.container_edu_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new RVFragEduAdapter(getContext(), educationList, position -> saveEducationDataToSharedPreferences());
        recyclerView.setAdapter(adapter);

        loadEducationDataFromSharedPreferences(); // Load data from SharedPreferences

        return view;
    }

    private void showEducationFormDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.form_frag_edu, null);

        final TextInputEditText degreeEd = view.findViewById(R.id.form_edu_et_degree);
        final TextInputEditText universityEd = view.findViewById(R.id.form_edu_et_university);
        final TextInputEditText gradeEd = view.findViewById(R.id.form_edu_et_grade);
        final TextInputEditText yearEd = view.findViewById(R.id.form_edu_et_year);

        builder.setView(view)
                .setTitle("Add Education")
                .setNeutralButton("Cancel", null)
                .setPositiveButton("Add", (dialogInterface, i) -> {
                    String degree = degreeEd.getText().toString();
                    String university = universityEd.getText().toString();
                    String grade = gradeEd.getText().toString();
                    String year = yearEd.getText().toString();

                    Education educationNew = new Education(degree, university, grade, year);
                    educationList.add(educationNew);
                    saveEducationDataToSharedPreferences(); // Save data to SharedPreferences

                    adapter.notifyDataSetChanged(); // Update RecyclerView

                    Toast.makeText(getContext(), "Data added", Toast.LENGTH_SHORT).show();
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void saveEducationDataToSharedPreferences() {
        Gson gson = new Gson();
        String json = gson.toJson(educationList);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_EDUCATION_LIST, json);
        editor.apply();
    }

    private void loadEducationDataFromSharedPreferences() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString(KEY_EDUCATION_LIST, null);
        Type type = new TypeToken<ArrayList<Education>>() {}.getType();
        educationList = gson.fromJson(json, type);

        if (educationList == null) {
            educationList = new ArrayList<>();
        }

        adapter.setEducationList(educationList);
        adapter.notifyDataSetChanged(); // Update RecyclerView
    }

    public void clearEducationData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        educationList.clear();
        adapter.notifyDataSetChanged();

        Toast.makeText(getContext(), "Education data cleared", Toast.LENGTH_SHORT).show();
    }

    public static class Education {
        private String degree;
        private String university;
        private String grade;
        private String year;

        public Education(String degree, String university, String grade, String year) {
            this.degree = degree;
            this.university = university;
            this.grade = grade;
            this.year = year;
        }

        public String getDegree() { return degree; }
        public String getUniversity() { return university; }
        public String getGrade() { return grade; }
        public String getYear() { return year; }
    }
}
