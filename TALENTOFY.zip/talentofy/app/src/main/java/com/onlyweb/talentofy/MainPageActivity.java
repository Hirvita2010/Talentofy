package com.onlyweb.talentofy;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.onlyweb.talentofy.databinding.ActivityMainPageBinding;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainPageActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    ActivityMainPageBinding binding;
    NavigationView nav;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    CircleImageView navHeaderProfileImage;
    TextView navHeaderUsername;
    TextView navHeaderEmail;
    TextView navHeaderPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set the initial fragment
        replaceFragment(new HomeFragment());

        // Set up BottomNavigationView
        binding.bottomNavigationView.setBackground(null);
        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.home) {
                replaceFragment(new HomeFragment());
            } else if (id == R.id.create) {
                replaceFragment(new EditDetailsFragment());
            } else if (id == R.id.template) {
                replaceFragment(new TemplateFragment());
            } else if (id == R.id.contact) {
                replaceFragment(new ContactFragment());
            } else {
                return false;
            }
            return true;
        });

        // Set up FloatingActionButton
        binding.fab.setOnClickListener(view -> showBottomDialog());

        // Set up Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set up Navigation Drawer
        nav = findViewById(R.id.navmenu);
        drawerLayout = findViewById(R.id.drawer);

        toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Set initial navigation item
        getSupportFragmentManager().beginTransaction().replace(R.id.container, new HomeFragment()).commit();
        nav.setCheckedItem(R.id.menu_profile);
        nav.setNavigationItemSelectedListener(this);

        // Initialize nav header profile image view
        View headerView = nav.getHeaderView(0);
        navHeaderProfileImage = headerView.findViewById(R.id.nav_header_profile_image);
        navHeaderUsername = headerView.findViewById(R.id.nav_header_username);
        navHeaderEmail = headerView.findViewById(R.id.nav_header_email);
        navHeaderPhone = headerView.findViewById(R.id.nav_header_phone);

        // Set click listener on nav header profile image to navigate to ProfileFragment
        navHeaderProfileImage.setOnClickListener(view -> {
            drawerLayout.closeDrawer(GravityCompat.START);
            replaceFragment(new ProfileFragment());
        });
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment);
        fragmentTransaction.commit();
    }

    public void setBottomNavigationVisibility(boolean isVisible) {
        int visibility = isVisible ? View.VISIBLE : View.GONE;
        binding.bottomNavigationView.setVisibility(visibility);
        binding.bottomAppBar.setVisibility(visibility);
        binding.fab.setVisibility(visibility);
    }

    private void showBottomDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.bottomsheetlayout);

        LinearLayout createLayout = dialog.findViewById(R.id.layoutCreate);
        LinearLayout existLayout = dialog.findViewById(R.id.layoutExist);
        ImageView cancelButton = dialog.findViewById(R.id.cancelButton);

        createLayout.setOnClickListener(v -> {
            dialog.dismiss();
            replaceFragment(new EditDetailsFragment());
        });

        existLayout.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(MainPageActivity.this, "Existing resume is Clicked", Toast.LENGTH_SHORT).show();
        });

        cancelButton.setOnClickListener(view -> dialog.dismiss());

        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setGravity(Gravity.BOTTOM);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment temp = null;

        int id = menuItem.getItemId();
        if (id == R.id.menu_profile) {
            temp = new ProfileFragment();
        } else if (id == R.id.menu_create) {
            temp = new EditDetailsFragment();
        } else if (id == R.id.menu_exist) {
            temp = new ExistingFragment();
        } else if (id == R.id.menu_logout) {
            showLogoutConfirmationDialog();
            return true; // Return true to prevent fragment replacement for logout option
        } else {
            temp = new HomeFragment(); // Default to home fragment if no match
        }

        replaceFragment(temp);
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showLogoutConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Logout user
                logoutUser();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Dismiss the dialog
                dialogInterface.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void logoutUser() {
        FirebaseAuth.getInstance().signOut();
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(getApplicationContext(), LoginPageActivity.class);
        startActivity(intent);
        finish();
    }

    // Method to update navigation header profile image
    public void updateNavHeaderProfileImage(String imageUrl) {
        if (imageUrl != null) {
            Uri imageUri = Uri.parse(imageUrl);
            Glide.with(this).load(imageUri).into(navHeaderProfileImage);
        }
    }
}
