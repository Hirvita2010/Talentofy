package com.onlyweb.talentofy;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


public class RegisterPageActivity extends AppCompatActivity {

    EditText name, email,phone, password, education, qualification;
    AppCompatButton signupbutton;
    FirebaseAuth mAuth; //Authentication
    FirebaseFirestore db;   //cloud db
    ProgressBar progressBar;
    TextView txt;

    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            Intent intent =new Intent(getApplicationContext(),MainPageActivity.class);
            startActivity(intent);
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        mAuth = FirebaseAuth.getInstance(); //Authentication
        db = FirebaseFirestore.getInstance(); //database

        name = findViewById(R.id.sign_name);
        email = findViewById(R.id.sign_email);
        phone = findViewById(R.id.sign_phone);
        password = findViewById(R.id.sign_pass);
        education = findViewById(R.id.sign_education);
        qualification = findViewById(R.id.sign_qualification);
        signupbutton =findViewById(R.id.sign_btn);
        progressBar =findViewById(R.id.progressBar);
        txt =findViewById(R.id.sign_tv);

        txt.setOnClickListener(v -> {
            Intent intent =new Intent(getApplicationContext(), LoginPageActivity.class);
            startActivity(intent);
            finish();
        });

        signupbutton.setOnClickListener(v -> {
            progressBar.setVisibility(View.VISIBLE);

            String Name, Email, Phone, Password, Education, Qualification;
            Name = name.getText().toString();
            Email = email.getText().toString();
            Phone = phone.getText().toString();
            Password = password.getText().toString();
            Education = education.getText().toString();
            Qualification = qualification.getText().toString();
            Map<String,Object> user = new HashMap<>();

            if(TextUtils.isEmpty(Name)){
                Toast.makeText(RegisterPageActivity.this,"Enter name",Toast.LENGTH_SHORT).show();
                return;
            }
            if(TextUtils.isEmpty(Email)){
                Toast.makeText(RegisterPageActivity.this,"Enter email",Toast.LENGTH_SHORT).show();
                return;
            }
            if(TextUtils.isEmpty(Password)){
                Toast.makeText(RegisterPageActivity.this,"Enter password",Toast.LENGTH_SHORT).show();
                return;
            }
            if(TextUtils.isEmpty(Phone)){
                Toast.makeText(RegisterPageActivity.this,"Enter phone",Toast.LENGTH_SHORT).show();
                return;
            }
            if(TextUtils.isEmpty(Education)){
                Toast.makeText(RegisterPageActivity.this,"Enter education",Toast.LENGTH_SHORT).show();
                return;
            }
            if(TextUtils.isEmpty(Qualification)){
                Toast.makeText(RegisterPageActivity.this,"Enter qualification",Toast.LENGTH_SHORT).show();
                return;
            }

            mAuth.createUserWithEmailAndPassword(Email, Password)
                    .addOnCompleteListener(task -> {
                        progressBar.setVisibility(View.GONE);
                        if (task.isSuccessful()) {
                            FirebaseUser firebaseUser = mAuth.getCurrentUser();
                            String userId = firebaseUser.getUid(); // Corrected here

                            user.put("Username", Name); // Removed ':' from keys
                            user.put("Email", Email);
                            user.put("Phone", Phone);
                            user.put("Password", Password);
                            user.put("Education", Education);
                            user.put("Qualification", Qualification);

                            db.collection("users").document(userId) // Corrected userId here
                                    .set(user)
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(RegisterPageActivity.this, "Account Created", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(RegisterPageActivity.this, MainPageActivity.class);
                                        startActivity(intent);
                                        finish();
                                    })
                                    .addOnFailureListener(e -> { // Changed to addOnFailureListener
                                        Toast.makeText(RegisterPageActivity.this, "Failed to register user. Please try again.", Toast.LENGTH_SHORT).show();
                                    });

                        } else {
                            Toast.makeText(RegisterPageActivity.this, "Authentication failed." + task.getException().getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
        });

    }
}