package model;

import android.net.Uri;

public class Resume {
    private String name;
    private Uri profileImageUri;

    public Resume(String name, Uri profileImageUri) {
        this.name = name;
        this.profileImageUri = profileImageUri;
    }

    // Add getters and setters for name and profileImageUri
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Uri getProfileImageUri() {
        return profileImageUri;
    }

    public void setProfileImageUri(Uri profileImageUri) {
        this.profileImageUri = profileImageUri;
    }
}
